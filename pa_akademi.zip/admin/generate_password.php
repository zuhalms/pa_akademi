<?php
// File: generate_password.php
$password = "admin123";
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "Password: " . $password . "<br>";
echo "Hash: " . $hash;
?>